<?php

$con = mysqli_connect("localhost", "root", "", "ecommerce") or die("Connection was not established. Error: ".mysqli_connect_error());


?>