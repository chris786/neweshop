<div>


<p style="text-align: center;"><img src="images/paypal.gif" width="250" height="150"/></p>

</div>